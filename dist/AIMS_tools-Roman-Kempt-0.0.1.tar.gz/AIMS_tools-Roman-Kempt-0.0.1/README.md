# AIMS_tools
Personal collection of scripts to handle AIMS calculations.
