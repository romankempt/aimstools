import numpy as np
from pathlib import Path as Path
import re
import ase.io
import os, sys


class hirshfeld:
    """ A simple class to evaluate Hirshfeld charge analysis from AIMS.

    Args:
        outputfile (str): Path to outputfile.

    Attributes:
        outputfile (pathlib object): Path to outputfile.
        path (pathlib object): Parent directory.
        atoms (Atoms object): ASE atoms object of geometry.in.
        charges (dict): Dictionary of (index, species) tuples and hirshfeld charges. 
        sum_charges (dict): Dictionary of species and summed hirshfeld charges.
    
    Todo:
        When needed, I'll implement features to relate geometry to charges, for example separating charges
        to different parts of the structure.
    """

    def __init__(self, outputfile):
        self.__check_output(outputfile)
        self.atoms = ase.io.read(self.outputfile.parent.joinpath("geometry.in"))
        self.charges = self.read_charges()
        self.sum_charges = self.sum_charges()

    def __check_output(self, outputfile):
        if Path(outputfile).is_file():
            check = os.popen(
                "tail -n 10 {filepath}".format(filepath=Path(outputfile))
            ).read()
            if "Have a nice day." in check:
                self.outputfile = Path(outputfile)
                self.path = self.outputfile.parent
            else:
                print("Calculation did not converge!")
                sys.exit()

        elif Path(outputfile).is_dir():
            outfiles = Path(outputfile).glob("*.out")
            for i in outfiles:
                check = os.popen("tail -n 10 {filepath}".format(filepath=i)).read()
                if "Have a nice day." in check:
                    self.outputfile = i
                    self.path = self.outputfile.parent
                else:
                    print("Calculation did not converge!")
                    sys.exit()
        else:
            print("Could not find outputfile.")
            sys.exit()

    def read_charges(self):
        with open(self.outputfile, "r") as file:
            ats = []
            charges = []
            read = False
            for line in file.readlines():
                if "Performing Hirshfeld analysis" in line:
                    read = True
                    i = 0
                if read:
                    if "Atom" in line:
                        ats.append(
                            (float(line.split()[-2].strip(":")), line.split()[-1])
                        )
                    if "Hirshfeld charge        :" in line:
                        charges.append(float(line.split()[-1]))
                        i += 1
                        if i == self.atoms.get_number_of_atoms():
                            read = False
        charges = dict(zip(ats, charges))
        return charges

    def sum_charges(self):
        sum_charges = {}
        for atom in self.charges.keys():
            species = atom[1]
            if species not in sum_charges.keys():
                sum_charges[species] = self.charges[atom]
            else:
                sum_charges[species] += self.charges[atom]
        return sum_charges

